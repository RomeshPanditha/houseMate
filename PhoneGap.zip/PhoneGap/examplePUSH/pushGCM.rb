require 'rubygems'
require 'pushmeup'
GCM.host = 'https://android.googleapis.com/gcm/send'
GCM.format = :json
GCM.key = "AIzaSyA1hvhEexT3eqQQHXgKE7DLU9FW2UZbkNs"
destination = ["APA91bEjNkYMb7wpVs3cm8EYM4Aa4kZ5aOD3799lwK7_Z81GrPQCVr3c7FskJ_5YFWli8jGgAfLxynyNfWvYSu81p_RkNttn4-MZ0DE5ZoFgLxqT-vtiaRoK9_lcctYOy_BsTvW1Ysc"]
data = {:message => "PhoneGap Build rocks!", :msgcnt => "1", :soundname => "beep.wav"}

GCM.send_notification( destination, data)
